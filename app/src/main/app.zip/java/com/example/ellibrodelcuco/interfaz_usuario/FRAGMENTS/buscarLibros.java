package com.example.ellibrodelcuco.interfaz_usuario.FRAGMENTS;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;
import com.example.ellibrodelcuco.R;
import com.example.ellibrodelcuco.interfaz_usuario.ADAPTERS.LibroAdapter;
import com.example.ellibrodelcuco.modelo.Libro;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QueryDocumentSnapshot;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

public class buscarLibros extends Fragment {

    private Button btnBuscar;
    private EditText etBusqueda;
    private ProgressBar progressBar;
    private RecyclerView rvResultados;
    private LibroAdapter adapter;
    private List<Libro> listaResultados;
    
    private RequestQueue requestQueue;
    private FirebaseFirestore db;
    private FirebaseAuth mAuth;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_buscar_libros, container, false);

        db = FirebaseFirestore.getInstance();
        mAuth = FirebaseAuth.getInstance();
        requestQueue = Volley.newRequestQueue(requireContext());

        btnBuscar = view.findViewById(R.id.btnBuscar);
        etBusqueda = view.findViewById(R.id.etBusqueda);
        progressBar = view.findViewById(R.id.progressBar);
        rvResultados = view.findViewById(R.id.rvResultados);

        rvResultados.setLayoutManager(new LinearLayoutManager(getContext()));
        listaResultados = new ArrayList<>();
        
        adapter = new LibroAdapter(listaResultados, libro -> {
            guardarLibroEnFirestore(libro);
        });
        rvResultados.setAdapter(adapter);

        sincronizarBotones();

        btnBuscar.setOnClickListener(v -> {
            String termino = etBusqueda.getText().toString().trim();
            if (!termino.isEmpty()) {
                buscarLibrosEnGoogle(termino);
            }
        });

        return view;
    }

    private void sincronizarBotones() {
        FirebaseUser user = mAuth.getCurrentUser();
        if (user != null) {
            db.collection("usuarios").document(user.getUid()).collection("biblioteca")
                .addSnapshotListener((value, error) -> {
                    if (value != null) {
                        List<String> titulos = new ArrayList<>();
                        for (QueryDocumentSnapshot doc : value) {
                            titulos.add(doc.getString("titulo"));
                        }
                        adapter.setTitulosGuardados(titulos);
                    }
                });
        }
    }

    private void buscarLibrosEnGoogle(String query) {
        progressBar.setVisibility(View.VISIBLE);
        listaResultados.clear();
        adapter.notifyDataSetChanged();

        String url = "https://www.googleapis.com/books/v1/volumes?q=" + query.replace(" ", "+") + "&maxResults=20";

        JsonObjectRequest request = new JsonObjectRequest(Request.Method.GET, url, null,
                response -> {
                    progressBar.setVisibility(View.GONE);
                    try {
                        if (response.has("items")) {
                            JSONArray items = response.getJSONArray("items");
                            for (int i = 0; i < items.length(); i++) {
                                JSONObject info = items.getJSONObject(i).getJSONObject("volumeInfo");
                                String titulo = info.optString("title", "Sin título");
                                String sinopsis = info.optString("description", "Sin sinopsis.");
                                JSONArray autoresArray = info.optJSONArray("authors");
                                String autor = (autoresArray != null) ? autoresArray.getString(0) : "Autor desconocido";
                                String portada = "";
                                JSONObject imageLinks = info.optJSONObject("imageLinks");
                                if (imageLinks != null) {
                                    portada = imageLinks.optString("thumbnail").replace("http:", "https:");
                                }
                                listaResultados.add(new Libro(titulo, autor, sinopsis, portada, "Pendiente"));
                            }
                            adapter.notifyDataSetChanged();
                        } else {
                            Toast.makeText(getContext(), "No se encontraron libros", Toast.LENGTH_SHORT).show();
                        }
                    } catch (Exception e) { e.printStackTrace(); }
                },
                error -> {
                    progressBar.setVisibility(View.GONE);
                    Toast.makeText(getContext(), "Error de conexión", Toast.LENGTH_SHORT).show();
                }
        );
        requestQueue.add(request);
    }

    private void guardarLibroEnFirestore(Libro libro) {
        FirebaseUser user = mAuth.getCurrentUser();
        if (user != null) {
            db.collection("usuarios").document(user.getUid())
                .collection("biblioteca").document(libro.getTitulo())
                .set(libro)
                .addOnSuccessListener(aVoid -> Toast.makeText(getContext(), "Libro añadido", Toast.LENGTH_SHORT).show());
        }
    }
}