package com.example.ellibrodelcuco.interfaz_usuario.FRAGMENTS;

import android.app.AlertDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.ellibrodelcuco.R;
import com.example.ellibrodelcuco.interfaz_usuario.ACTIVITIES.DetalleLibroActivity;
import com.example.ellibrodelcuco.interfaz_usuario.ADAPTERS.LibroAdapter;
import com.example.ellibrodelcuco.modelo.Libro;
import com.google.android.material.tabs.TabLayout;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QueryDocumentSnapshot;

import java.util.ArrayList;
import java.util.List;

public class perfil extends Fragment {

    private RecyclerView rvBiblioteca;
    private LibroAdapter libroAdapter;
    private List<Libro> listaLibrosFull, listaLibrosFiltrada;
    private TextView tvUserName, tvUserEmail, tvCountLeidos, tvLogroActual;
    private TabLayout tabLayout;

    private FirebaseFirestore db;
    private FirebaseAuth mAuth;
    private String categoriaActual = "Pendiente";

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_perfil, container, false);

        db = FirebaseFirestore.getInstance();
        mAuth = FirebaseAuth.getInstance();
        FirebaseUser user = mAuth.getCurrentUser();

        tvUserName = view.findViewById(R.id.tvUserName);
        tvUserEmail = view.findViewById(R.id.tvUserEmail);
        tvCountLeidos = view.findViewById(R.id.tvCountLeidos);
        
        // CORRECCIÓN DEFINITIVA: El ID en fragment_perfil.xml es tvLogroActual
        tvLogroActual = view.findViewById(R.id.tvLogroActual);

        rvBiblioteca = view.findViewById(R.id.rvBiblioteca);
        tabLayout = view.findViewById(R.id.tabLayoutCategorias);

        if (user != null) {
            tvUserEmail.setText(user.getEmail());
            tvUserName.setText(user.getDisplayName() != null && !user.getDisplayName().isEmpty() ? user.getDisplayName() : "Lector Cuco");
        }

        listaLibrosFull = new ArrayList<>();
        listaLibrosFiltrada = new ArrayList<>();
        rvBiblioteca.setLayoutManager(new LinearLayoutManager(getContext()));
        
        libroAdapter = new LibroAdapter(listaLibrosFiltrada, libro -> mostrarOpcionesLibro(libro));
        rvBiblioteca.setAdapter(libroAdapter);

        tabLayout.addOnTabSelectedListener(new TabLayout.OnTabSelectedListener() {
            @Override
            public void onTabSelected(TabLayout.Tab tab) {
                categoriaActual = tab.getText().toString();
                filtrarLibros();
            }
            @Override public void onTabUnselected(TabLayout.Tab tab) {}
            @Override public void onTabReselected(TabLayout.Tab tab) {}
        });

        if (user != null) cargarDatos(user.getUid());

        return view;
    }

    private void cargarDatos(String userId) {
        db.collection("usuarios").document(userId).collection("biblioteca")
            .addSnapshotListener((value, error) -> {
                if (value != null) {
                    listaLibrosFull.clear();
                    int leidosCount = 0;
                    for (QueryDocumentSnapshot doc : value) {
                        Libro libro = doc.toObject(Libro.class);
                        listaLibrosFull.add(libro);
                        if (libro.getEstado().equalsIgnoreCase("Leído")) leidosCount++;
                    }
                    actualizarEstadisticas(leidosCount);
                    filtrarLibros();
                }
            });
    }

    private void actualizarEstadisticas(int count) {
        if (tvCountLeidos != null) tvCountLeidos.setText(String.valueOf(count));
        
        String rango = "Novato";
        if (count >= 50) rango = "Erudito";
        else if (count >= 20) rango = "Bibliófilo";
        else if (count >= 10) rango = "Lector";
        else if (count >= 5) rango = "Aprendiz";

        if (tvLogroActual != null) tvLogroActual.setText(rango);
    }

    private void filtrarLibros() {
        listaLibrosFiltrada.clear();
        for (Libro l : listaLibrosFull) {
            if (l.getEstado().equalsIgnoreCase(categoriaActual)) {
                listaLibrosFiltrada.add(l);
            }
        }
        libroAdapter.notifyDataSetChanged();
    }

    private void mostrarOpcionesLibro(Libro libro) {
        // En lugar de un AlertDialog, abrimos la pantalla bonita de Detalles
        Intent intent = new Intent(getContext(), DetalleLibroActivity.class);
        intent.putExtra("libro", libro);
        startActivity(intent);
    }

    private void actualizarEstado(Libro libro, String nuevoEstado) {
        db.collection("usuarios").document(mAuth.getUid()).collection("biblioteca").document(libro.getTitulo())
            .update("estado", nuevoEstado);
    }

    private void borrarLibro(Libro libro) {
        db.collection("usuarios").document(mAuth.getUid()).collection("biblioteca").document(libro.getTitulo())
            .delete();
    }
}