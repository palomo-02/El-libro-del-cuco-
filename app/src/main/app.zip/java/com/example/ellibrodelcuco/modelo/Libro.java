package com.example.ellibrodelcuco.modelo;

import java.io.Serializable;

public class Libro implements Serializable {
    // Estos son los datos que vamos a guardar de cada libro
    private String titulo;
    private String autor;
    private String sinopsis;
    private String portadaUrl;
    private String estado; // "Leído", "Pendiente", etc.

    // Constructor vacío (OBLIGATORIO para Firebase)
    public Libro() { }

    // Constructor para crear libros nosotros
    public Libro(String titulo, String autor, String sinopsis, String portadaUrl, String estado) {
        this.titulo = titulo;
        this.autor = autor;
        this.sinopsis = sinopsis;
        this.portadaUrl = portadaUrl;
        this.estado = estado;
    }

    // Getters (Necesarios para leer los datos)
    public String getTitulo() { return titulo; }
    public String getAutor() { return autor; }
    public String getSinopsis() { return sinopsis; }
    public String getPortadaUrl() { return portadaUrl; }
    public String getEstado() { return estado; }
}