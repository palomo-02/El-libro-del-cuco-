package com.example.ellibrodelcuco.interfaz_usuario.ADAPTERS;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.ellibrodelcuco.R;
import com.example.ellibrodelcuco.modelo.Libro;
import com.squareup.picasso.Picasso;
import java.util.ArrayList;
import java.util.List;

public class LibroAdapter extends RecyclerView.Adapter<LibroAdapter.LibroViewHolder> {

    private List<Libro> listaLibros;
    private List<String> titulosGuardados = new ArrayList<>();
    private OnLibroClickListener listener;

    public interface OnLibroClickListener {
        void onLibroClick(Libro libro);
    }

    public LibroAdapter(List<Libro> listaLibros, OnLibroClickListener listener) {
        this.listaLibros = listaLibros;
        this.listener = listener;
    }

    public void setTitulosGuardados(List<String> titulos) {
        this.titulosGuardados = titulos;
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public LibroViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_libro, parent, false);
        return new LibroViewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull LibroViewHolder holder, int position) {
        Libro libro = listaLibros.get(position);
        holder.tvTitulo.setText(libro.getTitulo());
        holder.tvAutor.setText(libro.getAutor());

        if (libro.getPortadaUrl() != null && !libro.getPortadaUrl().isEmpty()) {
            String urlSegura = libro.getPortadaUrl().replace("http:", "https:");
            Picasso.get().load(urlSegura).into(holder.imgPortada);
        } else {
            holder.imgPortada.setImageResource(android.R.drawable.ic_menu_gallery);
        }

        // 1. Ocultamos el botón para que la tarjeta quede limpia
        View btnGuardar = holder.itemView.findViewById(R.id.btnGuardar);
        if (btnGuardar != null) {
            btnGuardar.setVisibility(View.GONE);
        }

        // 2. Hacemos que TODA la tarjeta sea pulsable
        // En "Buscar", esto añadirá el libro.
        // En "Perfil", esto abrirá los detalles del libro.
        holder.itemView.setOnClickListener(v -> {
            if (listener != null) listener.onLibroClick(libro);
        });
    }

    @Override
    public int getItemCount() {
        return listaLibros.size();
    }

    public static class LibroViewHolder extends RecyclerView.ViewHolder {
        TextView tvTitulo, tvAutor;
        ImageView imgPortada;

        public LibroViewHolder(@NonNull View itemView) {
            super(itemView);
            tvTitulo = itemView.findViewById(R.id.tvTitulo);
            tvAutor = itemView.findViewById(R.id.tvAutor);
            imgPortada = itemView.findViewById(R.id.imgPortada);
        }
    }
}