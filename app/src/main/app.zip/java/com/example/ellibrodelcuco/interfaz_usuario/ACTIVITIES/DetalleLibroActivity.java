package com.example.ellibrodelcuco.interfaz_usuario.ACTIVITIES;

import android.os.Bundle;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.ellibrodelcuco.R;
import com.example.ellibrodelcuco.modelo.Libro;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.FirebaseFirestore;
import com.squareup.picasso.Picasso;

public class DetalleLibroActivity extends AppCompatActivity {

    private ImageView ivPortada;
    private TextView tvTitulo, tvAutor, tvSinopsis, tvEstado;
    private Button btnPendiente, btnLeyendo, btnLeido, btnEliminar;

    private Libro libroActual;
    private FirebaseFirestore db;
    private FirebaseAuth mAuth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detalle_libro);

        // Ocultar barra superior
        if (getSupportActionBar() != null) getSupportActionBar().hide();

        db = FirebaseFirestore.getInstance();
        mAuth = FirebaseAuth.getInstance();

        // Enlazar vistas
        ivPortada = findViewById(R.id.ivDetallePortada);
        tvTitulo = findViewById(R.id.tvDetalleTitulo);
        tvAutor = findViewById(R.id.tvDetalleAutor);
        tvSinopsis = findViewById(R.id.tvDetalleSinopsis);
        tvEstado = findViewById(R.id.tvDetalleEstado);

        btnPendiente = findViewById(R.id.btnPendiente);
        btnLeyendo = findViewById(R.id.btnLeyendo);
        btnLeido = findViewById(R.id.btnLeido);
        btnEliminar = findViewById(R.id.btnEliminar);

        // 1. Recibir el libro desde la pantalla anterior
        if (getIntent().hasExtra("libro")) {
            libroActual = (Libro) getIntent().getSerializableExtra("libro");
            cargarDatosEnPantalla();
        } else {
            Toast.makeText(this, "Error al cargar el libro", Toast.LENGTH_SHORT).show();
            finish();
        }

        // 2. Configurar los botones de estado
        btnPendiente.setOnClickListener(v -> actualizarEstado("Pendiente"));
        btnLeyendo.setOnClickListener(v -> actualizarEstado("Leyendo"));
        btnLeido.setOnClickListener(v -> actualizarEstado("Leído"));

        // 3. Configurar botón de eliminar
        btnEliminar.setOnClickListener(v -> borrarLibro());
    }

    private void cargarDatosEnPantalla() {
        tvTitulo.setText(libroActual.getTitulo());
        tvAutor.setText(libroActual.getAutor());
        tvSinopsis.setText(libroActual.getSinopsis());
        tvEstado.setText("ESTADO: " + libroActual.getEstado().toUpperCase());

        if (libroActual.getPortadaUrl() != null && !libroActual.getPortadaUrl().isEmpty()) {
            Picasso.get().load(libroActual.getPortadaUrl()).into(ivPortada);
        } else {
            ivPortada.setImageResource(R.drawable.logo); // Tu logo por defecto
        }
    }

    private void actualizarEstado(String nuevoEstado) {
        if (mAuth.getCurrentUser() == null) return;

        db.collection("usuarios")
                .document(mAuth.getCurrentUser().getUid())
                .collection("biblioteca")
                .document(libroActual.getTitulo()) // OJO: Usas el título como ID en perfil.java
                .update("estado", nuevoEstado)
                .addOnSuccessListener(aVoid -> {
                    Toast.makeText(this, "Libro movido a " + nuevoEstado, Toast.LENGTH_SHORT).show();
                    tvEstado.setText("ESTADO: " + nuevoEstado.toUpperCase());
                });
    }

    private void borrarLibro() {
        if (mAuth.getCurrentUser() == null) return;

        db.collection("usuarios")
                .document(mAuth.getCurrentUser().getUid())
                .collection("biblioteca")
                .document(libroActual.getTitulo())
                .delete()
                .addOnSuccessListener(aVoid -> {
                    Toast.makeText(this, "Libro eliminado", Toast.LENGTH_SHORT).show();
                    finish(); // Cerramos la pantalla al eliminar
                });
    }
}


